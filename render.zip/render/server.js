 const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const app = express();

const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyrDav_JX5MtWQdFFspKeHEXlft875BCshBJ2KSJWqVN1JHrnxjKRASI0-VobARh0yc5w/exec";

app.use(cors());
app.use(express.json());

app.post('/submitEvaluation', async (req, res) => {
  try {
    const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=submitEvaluation`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const text = await response.text();
    res.status(200).send(text);
  } catch (err) {
    res.status(500).send("Error forwarding evaluation");
  }
});

app.post('/submitFeedback', async (req, res) => {
  try {
    const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=submitFeedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const text = await response.text();
    res.status(200).send(text);
  } catch (err) {
    res.status(500).send("Error forwarding feedback");
  }
});

app.get('/getLiveData', async (req, res) => {
  try {
    const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=getLiveData`);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).send("Error fetching live data");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ AHP-TOPSIS backend running on port ${PORT}`));
